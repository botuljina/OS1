#ifndef HFILES_QUEUE_H_
#define HFILES_QUEUE_H_
#include "Pcb.h"


class PCB;
class Thread;
class queue
{
	class qnode
		    {
		      public:
		        PCB* element;
		        qnode *next;

		        qnode(PCB* e = 0 ): element( e ), next( 0 )
		        { }
		    };

public:
	queue();
	~queue();

	friend Timer;
    friend PCB;
    friend semQueue;
    friend timeQueue;


	int isEmpty();
	int getQueueSize();

	void put(PCB* _pcb);
	PCB* get();

	void printQueueElements();
	Thread* getThreadById(int id);

	int queueLen;
private:
	qnode* firstNode;
	qnode* lastNode;

};

#endif
