#include "semQue.h"
#include "Timer.h"
#include "SCHEDULE.H"
#include <iostream.h>

timeQueue::timeQueue()
{
#ifndef BCC_BLOCK_IGNORE
	lock();
#endif
	myPcbSem = 0;
	firstNode = 0;
	lastNode = 0;
	queueLen = 0;
#ifndef BCC_BLOCK_IGNORE
	lock();
#endif
}

void timeQueue::put(PCB* _pcb,Time t)
{
#ifndef BCC_BLOCK_IGNORE
	lock();
#endif
	if ( isEmpty( ) == 1 )
	  {
	    firstNode = new qnode(_pcb,t);
	    lastNode = firstNode;
	    queueLen++;
	  }

	  else
	  {
	    qnode *p = new qnode(_pcb,t);

	    lastNode->next = p;
	    lastNode = lastNode->next;
	    queueLen++;
	  }
#ifndef BCC_BLOCK_IGNORE
	unlock();
#endif
}
PCB* timeQueue::get()
{
#ifndef BCC_BLOCK_IGNORE
	lock();
#endif
	qnode *temp ;
	PCB* element_for_return;


	if ( isEmpty( ) == 0 )
		  {
			queueLen--;
		    element_for_return = firstNode->element;
		    temp = firstNode;

		    //pomeram prvi
		    firstNode = firstNode->next;

		    delete temp;
		  }
#ifndef BCC_BLOCK_IGNORE
	unlock();
#endif
     return element_for_return;

}
timeQueue::~timeQueue()
{
#ifndef BCC_BLOCK_IGNORE
	lock();
#endif
	while (isEmpty()==0)
	    get();
	firstNode = 0;
	lastNode = 0;
#ifndef BCC_BLOCK_IGNORE
	unlock();
#endif
}


//Funkcija: Umanjim val i vadim node kojima je waitTime = 0
void timeQueue::decrementNodes()
{
	//ako je semafor prazan nemoj nista da decrementujes
	if(queueLen==0) return;
	qnode* previousNode = firstNode;
	qnode* node = previousNode->next;

	if(--previousNode->waitTime==0)
	{
		cout<<"decrementNodes in time queue -> if(--previousNode->waitTime==0)"<<endl;
		qnode* temp = previousNode;
		cout<<previousNode->waitTime<<endl;
		//pomeram pokazivace
		previousNode=node;
		node = node->next;

		temp->element->myPcbState = ready;
		Scheduler::put(temp->element);

		if(myPcbSem!=0) myPcbSem->val++;
		queueLen--;
		delete temp;
	}
	long i =0;
	while(node!=0)
	{

		if(--node->waitTime==0)
		{
			cout<<i++<<"->"<<"decrementNodes in time queue -> if(--previousNode->waitTime==0) in while loop"<<endl;

				qnode* temp = node;

				//prevezujem pokazivace
				previousNode->next = node->next;
				previousNode = node;
				node = previousNode->next;

				temp->element->myPcbState = ready;
				Scheduler::put(temp->element);

				if(myPcbSem!=0) myPcbSem->val++;

				queueLen--;
				delete temp;
		}
		else
		{
			previousNode = node;
			node = node->next;
		}

	}
	if(queueLen==0)
	{
		firstNode = 0;
		lastNode = 0;
	}
	//printQueueElements();
}

void timeQueue::printQueueElements()
{
#ifndef BCC_BLOCK_IGNORE
	lock();
#endif
	cout<<"IZBORIO SAM SE SA WHILE PETLJOM KRECE PRINT SVIH ELEMNATA NIZA KOJI TREBA DA BUDE MANJI ZBOG IZBACIVANJA"<<endl;
	qnode* temp = firstNode;
	while(temp!=0)
	{
		cout<<temp->waitTime<<",<-wait time elementa,quelen timequeue-a -> "<<queueLen<<"  |||";
		temp=temp->next;
	}
#ifndef BCC_BLOCK_IGNORE
	unlock();
#endif
}
int timeQueue::isEmpty()
{
	if(firstNode==0)return 1;
	else return 0;
}
